from django.apps import AppConfig


class TafmudappConfig(AppConfig):
    name = 'tafmudapp'
