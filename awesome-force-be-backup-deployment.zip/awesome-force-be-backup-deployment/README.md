# awesome-force-be-backup
This is going to be our BE built from scratch to avoid any issues from the Lambda Repo
